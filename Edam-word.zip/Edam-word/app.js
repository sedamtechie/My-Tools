/* Edam-word — Word-style document editor */
(function () {
  const doc = document.getElementById("doc");
  const page = document.getElementById("page");
  const nameInput = document.getElementById("doc-name");
  const dirtyEl = document.getElementById("dirty");
  const saveState = document.getElementById("save-state");
  const wordEl = document.getElementById("st-words");
  const fonts = ["Calibri", "Carlito", "Cambria", "Georgia", "Times New Roman", "Arial", "Segoe UI", "Verdana", "Tahoma", "Trebuchet MS", "Garamond", "Courier New", "Impact"];
  const sizes = [8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 36, 48, 72];
  const themeColors = ["#000000","#1a1a1a","#404040","#595959","#7f7f7f","#a6a6a6","#bfbfbf","#d9d9d9","#f2f2f2","#ffffff","#c00000","#ff0000","#ffc000","#ffff00","#92d050","#00b050","#00b0f0","#0070c0","#002060","#7030a0","#f4b183","#c65911","#833c0c","#1f4e79","#2e75b6","#5b9bd5","#9dc3e6","#bdd7ee","#deebf7","#fff2cc"];
  const highlights = ["#ffff00","#00ff00","#00ffff","#ff00ff","#0000ff","#ff0000","#00008b","#008080","#008000","#800080","#800000","#808000","#808080","#c0c0c0","#ffffff"];

  const state = {
    dirty: false,
    fileHandle: null,
    zoom: 100,
    margin: "normal",
    orient: "portrait",
    size: "letter",
    fontColor: "#c00000",
    highlight: "#ffff00",
    painter: null,
    spell: true,
    read: false
  };

  const welcome = `
    <h1>Edam-word</h1>
    <p>This is a Word-style editor. Open a <b>.docx</b>, edit it on the page, and save it back as Word.</p>
    <h2>What works like Word</h2>
    <ul>
      <li>Ribbon: Home, Insert, Layout, Review, View, and a File backstage.</li>
      <li>Fonts, sizes, bold, italic, underline, color, highlight, alignment, lists, styles.</li>
      <li>Tables, pictures, links, page breaks, margins, orientation, Letter and A4.</li>
      <li>Open <b>.docx</b> (and .txt / .html). Save as <b>.docx</b>, HTML, or plain text.</li>
      <li>In Chrome or Edge, Save can write back to the same file.</li>
    </ul>
    <h2>What this is not</h2>
    <p>It is not Microsoft Word. Macros, mail merge, SmartArt, equations, tracked changes, and unusual section layouts are out of scope. Everyday letters, reports, headings, lists, tables, and pictures round-trip.</p>
    <p>Try the ribbon, or use File → Open. Ctrl+S saves. Ctrl+F finds.</p>
  `;

  function toast(msg) {
    const t = document.getElementById("toast");
    t.textContent = msg;
    t.classList.add("show");
    clearTimeout(toast._t);
    toast._t = setTimeout(() => t.classList.remove("show"), 2800);
  }

  function markDirty() {
    state.dirty = true;
    dirtyEl.classList.add("on");
    saveState.textContent = "Unsaved";
    document.title = nameInput.value + " — Edam-word";
  }
  function markClean() {
    state.dirty = false;
    dirtyEl.classList.remove("on");
    saveState.textContent = "Saved";
  }

  function wordCount() {
    const text = doc.innerText.replace(/\u00a0/g, " ").trim();
    const words = text ? text.split(/\s+/).filter(Boolean).length : 0;
    wordEl.textContent = words + (words === 1 ? " word" : " words");
    return words;
  }

  let savedRange = null;
  function saveRange() {
    const sel = window.getSelection();
    if (!sel || !sel.rangeCount) return;
    const node = sel.anchorNode;
    if (node && (node === doc || doc.contains(node))) savedRange = sel.getRangeAt(0).cloneRange();
  }
  function restoreRange() {
    if (!savedRange) return;
    doc.focus();
    const sel = window.getSelection();
    sel.removeAllRanges();
    try { sel.addRange(savedRange); } catch (err) {}
  }
  function keepSelection(e) { e.preventDefault(); saveRange(); }

  function exec(cmd, val) {
    restoreRange();
    doc.focus();
    try { document.execCommand("styleWithCSS", false, true); } catch (err) {}
    const ok = document.execCommand(cmd, false, val == null ? null : val);
    if (!ok) applyWrap(cmd);
    saveRange();
    markDirty();
    wordCount();
  }
  function applyWrap(cmd) {
    const map = { bold: "strong", italic: "em", underline: "u", strikeThrough: "s", subscript: "sub", superscript: "sup" };
    const tag = map[cmd];
    if (!tag || !savedRange || savedRange.collapsed) return;
    const el = document.createElement(tag);
    try {
      savedRange.surroundContents(el);
    } catch (err) {
      el.appendChild(savedRange.extractContents());
      savedRange.insertNode(el);
    }
  }

  function applyFontSize(pt) {
    restoreRange();
    doc.focus();
    try { document.execCommand("styleWithCSS", false, true); } catch (err) {}
    document.execCommand("fontSize", false, "7");
    doc.querySelectorAll("font[size='7']").forEach((el) => {
      const span = document.createElement("span");
      span.style.fontSize = pt + "pt";
      while (el.firstChild) span.appendChild(el.firstChild);
      el.replaceWith(span);
    });
    doc.querySelectorAll("span").forEach((el) => {
      if ((el.style.fontSize || "") === "xxx-large" || el.style.fontSize === "48px") el.style.fontSize = pt + "pt";
    });
    saveRange();
    markDirty();
  }

  function applyFontName(name) {
    restoreRange();
    doc.focus();
    try { document.execCommand("styleWithCSS", false, true); } catch (err) {}
    document.execCommand("fontName", false, name);
    saveRange();
    markDirty();
  }

  function currentBlock() {
    const sel = window.getSelection();
    if (!sel || !sel.rangeCount) return null;
    let n = sel.anchorNode;
    if (n && n.nodeType === 3) n = n.parentElement;
    while (n && n !== doc) {
      if (/^(P|H1|H2|H3|LI|BLOCKQUOTE|DIV|TD|TH)$/.test(n.tagName)) return n;
      n = n.parentElement;
    }
    return doc;
  }

  function applyStyle(kind) {
    restoreRange();
    doc.focus();
    if (kind === "title") {
      document.execCommand("formatBlock", false, "h1");
      const b = currentBlock();
      if (b) { b.style.fontSize = "28pt"; b.style.color = "#1f4e79"; b.style.fontWeight = "300"; }
    } else if (kind === "blockquote") {
      document.execCommand("formatBlock", false, "blockquote");
    } else {
      document.execCommand("formatBlock", false, kind);
    }
    markDirty();
  }

  function fillSelects() {
    const fn = document.getElementById("font-name");
    fonts.forEach((f) => {
      const o = document.createElement("option");
      o.value = f; o.textContent = f; o.style.fontFamily = f;
      if (f === "Calibri") o.selected = true;
      fn.appendChild(o);
    });
    const fs = document.getElementById("font-size");
    sizes.forEach((s) => {
      const o = document.createElement("option");
      o.value = s; o.textContent = s;
      if (s === 11) o.selected = true;
      fs.appendChild(o);
    });
    fn.addEventListener("change", () => applyFontName(fn.value));
    fs.addEventListener("change", () => applyFontSize(Number(fs.value)));
    fn.addEventListener("mousedown", (e) => e.stopPropagation());
    fs.addEventListener("mousedown", (e) => e.stopPropagation());
  }

  function palette(el, colors, onPick) {
    colors.forEach((c) => {
      const i = document.createElement("i");
      i.style.background = c;
      i.title = c;
      i.addEventListener("mousedown", keepSelection);
      i.addEventListener("click", () => onPick(c));
      el.appendChild(i);
    });
  }

  function bindRibbon() {
    document.querySelectorAll("[data-cmd]").forEach((btn) => {
      btn.addEventListener("mousedown", keepSelection);
      btn.addEventListener("click", () => exec(btn.dataset.cmd));
    });
    document.querySelectorAll("[data-style]").forEach((btn) => {
      btn.addEventListener("mousedown", keepSelection);
      btn.addEventListener("click", () => applyStyle(btn.dataset.style));
    });
    document.getElementById("grow").addEventListener("mousedown", keepSelection);
    document.getElementById("shrink").addEventListener("mousedown", keepSelection);
    document.getElementById("clear").addEventListener("mousedown", keepSelection);
    document.getElementById("grow").addEventListener("click", () => {
      const cur = Number(document.getElementById("font-size").value) || 11;
      const next = sizes.find((s) => s > cur) || cur;
      document.getElementById("font-size").value = next;
      applyFontSize(next);
    });
    document.getElementById("shrink").addEventListener("click", () => {
      const cur = Number(document.getElementById("font-size").value) || 11;
      const next = [...sizes].reverse().find((s) => s < cur) || cur;
      document.getElementById("font-size").value = next;
      applyFontSize(next);
    });
    document.getElementById("clear").addEventListener("click", () => exec("removeFormat"));

    document.getElementById("cut").addEventListener("click", () => exec("cut"));
    document.getElementById("copy").addEventListener("click", () => exec("copy"));
    document.getElementById("paste").addEventListener("click", async () => {
      doc.focus();
      try {
        const text = await navigator.clipboard.readText();
        document.execCommand("insertText", false, text);
        markDirty();
      } catch (e) {
        toast("Browser blocked paste. Use Ctrl+V in the page.");
      }
    });

    document.getElementById("format-painter").addEventListener("mousedown", keepSelection);
    document.getElementById("format-painter").addEventListener("click", () => {
      const sel = window.getSelection();
      if (!sel.rangeCount) return;
      let n = sel.anchorNode;
      if (n && n.nodeType === 3) n = n.parentElement;
      if (!n) return;
      state.painter = {
        fontWeight: getComputedStyle(n).fontWeight,
        fontStyle: getComputedStyle(n).fontStyle,
        textDecoration: getComputedStyle(n).textDecoration,
        color: getComputedStyle(n).color,
        fontSize: getComputedStyle(n).fontSize,
        fontFamily: getComputedStyle(n).fontFamily
      };
      toast("Formatting copied. Select text to paint.");
      doc.addEventListener("mouseup", paintOnce);
    });

    const fontPop = document.getElementById("font-pop");
    const hlPop = document.getElementById("hl-pop");
    const tablePop = document.getElementById("table-pop");
    document.getElementById("font-color-btn").addEventListener("mousedown", keepSelection);
    document.getElementById("hl-btn").addEventListener("mousedown", keepSelection);
    document.getElementById("font-color-btn").addEventListener("click", () => {
      fontPop.classList.toggle("open"); hlPop.classList.remove("open");
    });
    document.getElementById("hl-btn").addEventListener("click", () => {
      hlPop.classList.toggle("open"); fontPop.classList.remove("open");
    });
    palette(document.getElementById("font-palette"), themeColors, (c) => {
      state.fontColor = c;
      document.getElementById("font-color-bar").style.background = c;
      fontPop.classList.remove("open");
      exec("foreColor", c);
    });
    palette(document.getElementById("hl-palette"), highlights, (c) => {
      state.highlight = c;
      hlPop.classList.remove("open");
      exec("hiliteColor", c);
    });

    document.getElementById("line-spacing").addEventListener("change", (e) => {
      const b = currentBlock();
      if (b && b !== doc) b.style.lineHeight = e.target.value;
      markDirty();
    });

    document.querySelectorAll(".tab").forEach((tab) => {
      tab.addEventListener("click", () => {
        if (tab.dataset.tab === "file") { openBackstage("info"); return; }
        document.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
        tab.classList.add("active");
        document.querySelectorAll(".panel").forEach((p) => {
          p.style.display = p.dataset.panel === tab.dataset.tab ? "flex" : "none";
        });
        document.getElementById("ribbon").classList.remove("hidden");
      });
    });

    buildTablePicker();
    document.getElementById("table-btn").addEventListener("click", () => tablePop.classList.toggle("open"));
    document.getElementById("pic-btn").addEventListener("click", () => document.getElementById("img-input").click());
    document.getElementById("link-btn").addEventListener("click", insertLink);
    document.getElementById("break-btn").addEventListener("mousedown", keepSelection);
    document.getElementById("break-btn").addEventListener("click", () => {
      document.execCommand("insertHTML", false, '<div class="page-break" contenteditable="false"></div><p><br></p>');
      markDirty();
    });
    document.getElementById("hr-btn").addEventListener("mousedown", keepSelection);
    document.getElementById("hr-btn").addEventListener("click", () => exec("insertHorizontalRule"));
    document.getElementById("box-btn").addEventListener("mousedown", keepSelection);
    document.getElementById("box-btn").addEventListener("click", () => {
      document.execCommand("insertHTML", false, '<div class="text-box"><p>Text box</p></div><p><br></p>');
      markDirty();
    });

    document.querySelectorAll("[data-margin]").forEach((b) => b.addEventListener("click", () => {
      page.classList.remove("m-narrow", "m-wide");
      state.margin = b.dataset.margin;
      if (b.dataset.margin !== "normal") page.classList.add(b.dataset.margin);
      markDirty();
    }));
    document.querySelectorAll("[data-orient]").forEach((b) => b.addEventListener("click", () => {
      state.orient = b.dataset.orient;
      page.classList.toggle("landscape", state.orient === "landscape");
      syncRuler();
      markDirty();
    }));
    document.querySelectorAll("[data-size]").forEach((b) => b.addEventListener("click", () => {
      state.size = b.dataset.size;
      page.classList.toggle("a4", state.size === "a4");
      syncRuler();
      markDirty();
    }));

    document.getElementById("count-btn").addEventListener("click", showCount);
    document.getElementById("st-words").addEventListener("click", showCount);
    document.getElementById("spell-btn").addEventListener("click", toggleSpell);
    document.getElementById("st-spell").addEventListener("click", toggleSpell);
    document.getElementById("toggle-ruler").addEventListener("click", () => {
      document.getElementById("ruler").classList.toggle("hidden");
    });
    document.getElementById("toggle-ribbon").addEventListener("click", () => {
      document.getElementById("ribbon").classList.toggle("hidden");
    });
    document.getElementById("read-mode").addEventListener("click", () => {
      state.read = true;
      document.getElementById("ribbon").classList.add("hidden");
      document.getElementById("workspace").classList.add("read");
      document.getElementById("st-layout").textContent = "Read mode";
    });
    document.getElementById("print-layout").addEventListener("click", () => {
      state.read = false;
      document.getElementById("ribbon").classList.remove("hidden");
      document.getElementById("workspace").classList.remove("read");
      document.getElementById("st-layout").textContent = "Print layout";
    });

    document.addEventListener("click", (e) => {
      if (!e.target.closest(".color-wrap")) {
        fontPop.classList.remove("open");
        hlPop.classList.remove("open");
        tablePop.classList.remove("open");
      }
    });
  }

  function paintOnce() {
    const sel = window.getSelection();
    if (!state.painter || !sel || sel.isCollapsed) return;
    const s = state.painter;
    document.execCommand("fontName", false, s.fontFamily.split(",")[0].replace(/"/g, ""));
    if (parseInt(s.fontWeight, 10) >= 600 || s.fontWeight === "bold") document.execCommand("bold");
    if (s.fontStyle === "italic") document.execCommand("italic");
    if (s.textDecoration && s.textDecoration.includes("underline")) document.execCommand("underline");
    document.execCommand("foreColor", false, s.color);
    state.painter = null;
    doc.removeEventListener("mouseup", paintOnce);
    markDirty();
    toast("Formatting applied");
  }

  function buildTablePicker() {
    const grid = document.getElementById("table-grid");
    const label = document.getElementById("grid-label");
    const cells = [];
    for (let r = 1; r <= 6; r++) {
      for (let c = 1; c <= 8; c++) {
        const b = document.createElement("b");
        b.dataset.r = r; b.dataset.c = c;
        b.addEventListener("mouseenter", () => {
          cells.forEach((x) => x.classList.toggle("on", x.dataset.r <= r && x.dataset.c <= c));
          label.textContent = c + " × " + r + " table";
        });
        b.addEventListener("mousedown", keepSelection);
        b.addEventListener("click", () => insertTable(r, c));
        grid.appendChild(b);
        cells.push(b);
      }
    }
  }

  function insertTable(rows, cols) {
    let html = "<table><tbody>";
    for (let r = 0; r < rows; r++) {
      html += "<tr>";
      for (let c = 0; c < cols; c++) html += r === 0 ? "<th>&nbsp;</th>" : "<td>&nbsp;</td>";
      html += "</tr>";
    }
    html += "</tbody></table><p><br></p>";
    document.getElementById("table-pop").classList.remove("open");
    doc.focus();
    document.execCommand("insertHTML", false, html);
    markDirty();
  }

  function insertLink() {
    openModal("Insert link", `
      <label>Text</label><input id="m-text" />
      <label>Address</label><input id="m-url" placeholder="https://" />
    `, () => {
      const text = document.getElementById("m-text").value || document.getElementById("m-url").value;
      let url = document.getElementById("m-url").value.trim();
      if (!url) return;
      if (!/^https?:|^mailto:/i.test(url)) url = "https://" + url;
      doc.focus();
      document.execCommand("insertHTML", false, '<a href="' + escapeAttr(url) + '">' + escapeHtml(text) + "</a>");
      markDirty();
    });
    const sel = window.getSelection();
    setTimeout(() => {
      const t = document.getElementById("m-text");
      if (t && sel) t.value = sel.toString();
    }, 0);
  }

  function showCount() {
    const text = doc.innerText || "";
    const words = wordCount();
    const chars = text.replace(/\s/g, "").length;
    const paras = doc.querySelectorAll("p,h1,h2,h3,li,blockquote").length;
    openModal("Word count", `
      <div class="info-grid">
        <div>Words</div><div>${words}</div>
        <div>Characters (no spaces)</div><div>${chars}</div>
        <div>Characters (with spaces)</div><div>${text.length}</div>
        <div>Paragraphs</div><div>${paras}</div>
      </div>
    `, () => {}, true);
  }

  function toggleSpell() {
    state.spell = !state.spell;
    doc.spellcheck = state.spell;
    document.getElementById("st-spell").textContent = "Spelling: " + (state.spell ? "on" : "off");
  }

  function openModal(title, body, onOk, infoOnly) {
    document.getElementById("modal-title").textContent = title;
    document.getElementById("modal-body").innerHTML = body;
    document.getElementById("modal").classList.add("open");
    document.getElementById("modal-ok").style.display = infoOnly ? "none" : "";
    const close = () => document.getElementById("modal").classList.remove("open");
    document.getElementById("modal-cancel").onclick = close;
    document.getElementById("modal-ok").onclick = () => { onOk(); close(); };
  }

  function syncRuler() {
    const el = document.getElementById("ruler-inner");
    el.style.width = page.classList.contains("landscape")
      ? (page.classList.contains("a4") ? "11.69in" : "11in")
      : (page.classList.contains("a4") ? "8.27in" : "8.5in");
  }

  function setZoom(z) {
    state.zoom = Math.max(50, Math.min(200, z));
    page.style.zoom = state.zoom / 100;
    document.getElementById("zoom").value = state.zoom;
    document.getElementById("zoom-label").textContent = state.zoom + "%";
  }

  /* ---------- file ---------- */
  function newDoc() {
    if (state.dirty && !confirm("Discard unsaved changes?")) return;
    doc.innerHTML = "<p><br></p>";
    nameInput.value = "Document1";
    state.fileHandle = null;
    markClean();
    wordCount();
    document.title = "Document1 — Edam-word";
    closeBackstage();
    doc.focus();
  }

  async function openFile() {
    if (window.showOpenFilePicker) {
      try {
        const [handle] = await window.showOpenFilePicker({
          types: [{
            description: "Documents",
            accept: {
              "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"],
              "text/plain": [".txt"],
              "text/html": [".html", ".htm"]
            }
          }]
        });
        state.fileHandle = handle;
        const file = await handle.getFile();
        await loadFile(file);
        closeBackstage();
        return;
      } catch (e) {
        if (e && e.name === "AbortError") return;
      }
    }
    document.getElementById("file-input").click();
  }

  async function loadFile(file) {
    const lower = file.name.toLowerCase();
    nameInput.value = file.name.replace(/\.[^.]+$/, "");
    try {
      if (lower.endsWith(".docx")) {
        if (typeof mammoth === "undefined") throw new Error("Docx reader failed to load");
        const buf = await file.arrayBuffer();
        const result = await mammoth.convertToHtml({ arrayBuffer: buf }, {
          styleMap: [
            "p[style-name='Title'] => h1:fresh",
            "p[style-name='Heading 1'] => h1:fresh",
            "p[style-name='Heading 2'] => h2:fresh",
            "p[style-name='Heading 3'] => h3:fresh",
            "p[style-name='Quote'] => blockquote:fresh"
          ]
        });
        doc.innerHTML = result.value || "<p><br></p>";
        if (result.messages && result.messages.length) {
          toast("Opened with " + result.messages.length + " note" + (result.messages.length > 1 ? "s" : "") + " — unusual Word objects may be simplified.");
        } else toast("Opened " + file.name);
      } else if (lower.endsWith(".html") || lower.endsWith(".htm")) {
        const text = await file.text();
        const parsed = new DOMParser().parseFromString(text, "text/html");
        doc.innerHTML = parsed.body ? parsed.body.innerHTML : text;
        toast("Opened " + file.name);
      } else {
        const text = await file.text();
        doc.innerHTML = text.split(/\n/).map((line) => "<p>" + (escapeHtml(line) || "<br>") + "</p>").join("");
        toast("Opened " + file.name);
      }
      markClean();
      wordCount();
      document.title = nameInput.value + " — Edam-word";
    } catch (err) {
      toast("Could not open: " + err.message);
    }
  }

  async function save(asCopy) {
    let blob;
    try {
      blob = await buildDocxBlob();
    } catch (err) {
      toast("Save failed: " + err.message);
      return;
    }
    const filename = (nameInput.value || "Document1").replace(/[\\/:*?"<>|]/g, "") + ".docx";
    if (!asCopy && state.fileHandle && state.fileHandle.createWritable) {
      try {
        const writable = await state.fileHandle.createWritable();
        await writable.write(blob);
        await writable.close();
        markClean();
        toast("Saved " + filename);
        return;
      } catch (e) {
        toast("Could not write the original file. Downloading instead.");
      }
    }
    if (!asCopy && location.protocol !== "file:" && window.showSaveFilePicker) {
      try {
        const handle = await window.showSaveFilePicker({
          suggestedName: filename,
          types: [{ description: "Word document", accept: { "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"] } }]
        });
        state.fileHandle = handle;
        const writable = await handle.createWritable();
        await writable.write(blob);
        await writable.close();
        markClean();
        toast("Saved " + filename);
        return;
      } catch (e) {
        if (e && e.name === "AbortError") return;
      }
    }
    downloadBlob(blob, filename);
    markClean();
    toast("Downloaded " + filename);
  }

  function baseName() {
    return (nameInput.value || "Document1").replace(/[\\/:*?"<>|]/g, "") || "Document1";
  }
  function exportHtml() {
    const html = "<!DOCTYPE html><html><head><meta charset='utf-8'><title>" +
      escapeHtml(nameInput.value) + "</title></head><body>" + doc.innerHTML + "</body></html>";
    downloadBlob(new Blob([html], { type: "text/html" }), baseName() + ".html");
    toast("Downloaded " + baseName() + ".html");
  }
  function exportTxt() {
    downloadBlob(new Blob([doc.innerText], { type: "text/plain" }), baseName() + ".txt");
    toast("Downloaded " + baseName() + ".txt");
  }
  function exportMd() {
    downloadBlob(new Blob([toMarkdown(doc)], { type: "text/markdown" }), baseName() + ".md");
    toast("Downloaded " + baseName() + ".md");
  }
  function exportRtf() {
    downloadBlob(new Blob([toRtf(doc)], { type: "application/rtf" }), baseName() + ".rtf");
    toast("Downloaded " + baseName() + ".rtf");
  }
  function exportPdf() {
    const pdf = textToPdf(doc.innerText || "");
    downloadBlob(new Blob([pdf], { type: "application/pdf" }), baseName() + ".pdf");
    toast("Downloaded " + baseName() + ".pdf");
  }
  function openSaveDialog() {
    const box = document.querySelector("#modal .modal");
    if (box) box.classList.add("wide");
    openModal("Save as", `
      <p class="lead" style="margin:0 0 8px">Pick a format. The file downloads to your computer. Ctrl+S still saves Word (.docx).</p>
      <div class="fmt-grid" id="fmt-grid">
        <button type="button" data-fmt="docx"><strong>Word document</strong><span>.docx — opens in Word</span></button>
        <button type="button" data-fmt="pdf"><strong>PDF</strong><span>.pdf — text layout</span></button>
        <button type="button" data-fmt="rtf"><strong>Rich Text</strong><span>.rtf — bold, italic, headings</span></button>
        <button type="button" data-fmt="html"><strong>Web page</strong><span>.html</span></button>
        <button type="button" data-fmt="md"><strong>Markdown</strong><span>.md</span></button>
        <button type="button" data-fmt="txt"><strong>Plain text</strong><span>.txt</span></button>
      </div>
    `, function () {}, true);
    document.querySelectorAll("#fmt-grid button").forEach((btn) => {
      btn.onclick = function () {
        document.getElementById("modal").classList.remove("open");
        if (box) box.classList.remove("wide");
        saveAs(btn.dataset.fmt);
      };
    });
  }
  function saveAs(fmt) {
    if (fmt === "docx") return save(true);
    if (fmt === "html") return exportHtml();
    if (fmt === "txt") return exportTxt();
    if (fmt === "md") return exportMd();
    if (fmt === "rtf") return exportRtf();
    if (fmt === "pdf") return exportPdf();
  }
  function rtfEscape(s) {
    return String(s).replace(/\\/g, "\\\\").replace(/\{/g, "\\{").replace(/\}/g, "\\}")
      .replace(/[^\x00-\x7f]/g, (ch) => "\\u" + ch.charCodeAt(0) + "?");
  }
  function toRtf(root) {
    let out = "{\\rtf1\\ansi\\deff0{\\fonttbl{\\f0 Calibri;}}\\f0\\fs22 ";
    function runs(node) {
      node.childNodes.forEach((n) => {
        if (n.nodeType === 3) { out += rtfEscape(n.textContent); return; }
        if (n.nodeType !== 1) return;
        const tag = n.tagName;
        if (tag === "BR") { out += "\\line "; return; }
        if (tag === "B" || tag === "STRONG") { out += "\\b "; runs(n); out += "\\b0 "; return; }
        if (tag === "I" || tag === "EM") { out += "\\i "; runs(n); out += "\\i0 "; return; }
        if (tag === "U") { out += "\\ul "; runs(n); out += "\\ul0 "; return; }
        runs(n);
      });
    }
    function blocks(node) {
      node.childNodes.forEach((n) => {
        if (n.nodeType !== 1) return;
        const tag = n.tagName;
        if (tag === "H1") { out += "\\fs32\\b "; runs(n); out += "\\b0\\fs22\\par "; return; }
        if (tag === "H2") { out += "\\fs28\\b "; runs(n); out += "\\b0\\fs22\\par "; return; }
        if (tag === "H3") { out += "\\fs24\\b "; runs(n); out += "\\b0\\fs22\\par "; return; }
        if (tag === "UL" || tag === "OL") { blocks(n); return; }
        if (tag === "LI") { out += "\\bullet  "; runs(n); out += "\\par "; return; }
        if (tag === "TABLE") { blocks(n); return; }
        if (tag === "TR") { blocks(n); out += "\\par "; return; }
        if (tag === "TD" || tag === "TH") { runs(n); out += "\\tab "; return; }
        if (tag === "DIV") { blocks(n); return; }
        runs(n); out += "\\par ";
      });
    }
    blocks(root);
    out += "}";
    return out;
  }
  function mdEscape(s) { return String(s).replace(/([\\`*_{}\[\]()#+!|])/g, "\\$1"); }
  function toMarkdown(root) {
    const lines = [];
    function inline(node) {
      let s = "";
      node.childNodes.forEach((n) => {
        if (n.nodeType === 3) { s += n.textContent; return; }
        if (n.nodeType !== 1) return;
        const tag = n.tagName;
        const inner = inline(n);
        if (tag === "B" || tag === "STRONG") s += "**" + inner + "**";
        else if (tag === "I" || tag === "EM") s += "*" + inner + "*";
        else if (tag === "A") s += "[" + inner + "](" + (n.getAttribute("href") || "") + ")";
        else if (tag === "BR") s += "  \n";
        else s += inner;
      });
      return s;
    }
    function walk(node) {
      node.childNodes.forEach((n) => {
        if (n.nodeType !== 1) return;
        const tag = n.tagName;
        if (tag === "H1") lines.push("# " + inline(n).trim());
        else if (tag === "H2") lines.push("## " + inline(n).trim());
        else if (tag === "H3") lines.push("### " + inline(n).trim());
        else if (tag === "UL") n.querySelectorAll(":scope > li").forEach((li) => lines.push("- " + inline(li).trim()));
        else if (tag === "OL") {
          let i = 1;
          n.querySelectorAll(":scope > li").forEach((li) => lines.push((i++) + ". " + inline(li).trim()));
        } else if (tag === "BLOCKQUOTE") lines.push("> " + inline(n).trim());
        else if (tag === "TABLE") {
          const rows = [...n.rows].map((r) => [...r.cells].map((c) => inline(c).trim().replace(/\|/g, "\\|")));
          if (rows.length) {
            lines.push("| " + rows[0].join(" | ") + " |");
            lines.push("| " + rows[0].map(() => "---").join(" | ") + " |");
            rows.slice(1).forEach((r) => lines.push("| " + r.join(" | ") + " |"));
          }
        } else if (tag === "DIV") walk(n);
        else if (tag === "P" || tag === "LI") lines.push(inline(n).trim());
      });
    }
    walk(root);
    return lines.filter((l) => l != null).join("\n\n") + "\n";
  }
  function textToPdf(text) {
    const lines = [];
    String(text).split(/\n/).forEach((para) => {
      const words = para.split(/\s+/);
      let cur = "";
      words.forEach((w) => {
        if ((cur + " " + w).trim().length > 90) { lines.push(cur.trim()); cur = w; }
        else cur = (cur + " " + w).trim();
      });
      lines.push(cur);
      lines.push("");
    });
    const pages = [];
    for (let i = 0; i < lines.length; i += 46) pages.push(lines.slice(i, i + 46));
    if (!pages.length) pages.push([""]);
    const objects = [];
    function add(body) { objects.push(body); return objects.length; }
    const pageIds = [];
    const fontId = 3;
    pages.forEach((pageLines, idx) => {
      let stream = "BT /F1 11 Tf 54 760 Td 14 TL\n";
      pageLines.forEach((line) => {
        const safe = line.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)").replace(/[^\x20-\x7e]/g, "?");
        stream += "(" + safe + ") '\n";
      });
      stream += "ET";
      const contentId = add("<< /Length " + stream.length + " >>\nstream\n" + stream + "\nendstream");
      const pageId = add("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents " + contentId + " 0 R /Resources << /Font << /F1 " + fontId + " 0 R >> >> >>");
      pageIds.push(pageId);
    });
    // rebuild with fixed ids: catalog 1, pages 2, font 3, then contents/pages already numbered from 1 — this is wrong.
    return buildPdf(pages);
  }
  function buildPdf(pages) {
    const chunks = [];
    const offsets = [0];
    let pdf = "%PDF-1.4\n";
    function addObj(n, body) {
      offsets[n] = pdf.length;
      pdf += n + " 0 obj\n" + body + "\nendobj\n";
    }
    const nPages = pages.length;
    const fontId = 3;
    const firstContent = 4;
    addObj(1, "<< /Type /Catalog /Pages 2 0 R >>");
    const kids = pages.map((_, i) => (firstContent + nPages + i) + " 0 R").join(" ");
    addObj(2, "<< /Type /Pages /Count " + nPages + " /Kids [" + kids + "] >>");
    addObj(3, "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");
    pages.forEach((pageLines, i) => {
      let stream = "BT /F1 11 Tf 54 760 Td 14 TL\n";
      pageLines.forEach((line) => {
        const safe = String(line).replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)").replace(/[^\x20-\x7e]/g, "?");
        stream += "(" + safe + ") '\n";
      });
      stream += "ET";
      addObj(firstContent + i, "<< /Length " + stream.length + " >>\nstream\n" + stream + "\nendstream");
    });
    pages.forEach((_, i) => {
      const contentId = firstContent + i;
      const pageId = firstContent + nPages + i;
      addObj(pageId, "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents " + contentId + " 0 R /Resources << /Font << /F1 " + fontId + " 0 R >> >> >>");
    });
    const xrefPos = pdf.length;
    const count = firstContent + nPages * 2;
    pdf += "xref\n0 " + count + "\n";
    pdf += "0000000000 65535 f \n";
    for (let i = 1; i < count; i++) pdf += String(offsets[i] || 0).padStart(10, "0") + " 00000 n \n";
    pdf += "trailer << /Size " + count + " /Root 1 0 R >>\nstartxref\n" + xrefPos + "\n%%EOF";
    return pdf;
  }
  function downloadBlob(blob, filename) {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1500);
  }

  /* ---------- docx writer ---------- */
  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, "\u0026amp;")
      .replace(/</g, "\u0026lt;")
      .replace(/>/g, "\u0026gt;");
  }
  function escapeAttr(s) {
    return escapeHtml(s).replace(/"/g, "\u0026quot;");
  }
  function escapeXml(s) {
    return String(s)
      .replace(/&/g, "\u0026amp;")
      .replace(/</g, "\u0026lt;")
      .replace(/>/g, "\u0026gt;");
  }
  function cssColorToHex(c) {
    if (!c) return null;
    c = c.trim();
    if (c.startsWith("#")) {
      if (c.length === 4) return (c[1] + c[1] + c[2] + c[2] + c[3] + c[3]).toUpperCase();
      return c.slice(1, 7).toUpperCase();
    }
    const m = c.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
    if (!m) return null;
    return [m[1], m[2], m[3]].map((n) => Number(n).toString(16).padStart(2, "0")).join("").toUpperCase();
  }
  function ptFromCss(size) {
    if (!size) return null;
    if (size.endsWith("pt")) return Math.round(parseFloat(size) * 2);
    if (size.endsWith("px")) return Math.round(parseFloat(size) * 0.75 * 2);
    return null;
  }

  function inheritStyle(node, base) {
    const s = Object.assign({}, base);
    if (!node || node.nodeType !== 1) return s;
    const tag = node.tagName;
    if (tag === "B" || tag === "STRONG") s.bold = true;
    if (tag === "I" || tag === "EM") s.italic = true;
    if (tag === "U") s.underline = true;
    if (tag === "S" || tag === "STRIKE" || tag === "DEL") s.strike = true;
    if (tag === "SUB") s.sub = true;
    if (tag === "SUP") s.sup = true;
    if (tag === "A" && node.getAttribute("href")) s.href = node.getAttribute("href");
    if (tag === "FONT") {
      if (node.color) s.color = cssColorToHex(node.color) || s.color;
      if (node.face) s.font = node.face;
    }
    const st = node.style;
    if (st) {
      if (st.fontWeight === "bold" || parseInt(st.fontWeight, 10) >= 600) s.bold = true;
      if (st.fontStyle === "italic") s.italic = true;
      const deco = st.textDecorationLine || st.textDecoration || "";
      if (deco.includes("underline")) s.underline = true;
      if (deco.includes("line-through")) s.strike = true;
      if (st.color) s.color = cssColorToHex(st.color) || s.color;
      if (st.backgroundColor && st.backgroundColor !== "transparent") s.fill = cssColorToHex(st.backgroundColor) || s.fill;
      if (st.fontSize) s.sz = ptFromCss(st.fontSize) || s.sz;
      if (st.fontFamily) s.font = st.fontFamily.split(",")[0].replace(/['"]/g, "").trim();
    }
    return s;
  }

  function runsFrom(node, style, images) {
    const out = [];
    function walk(n, st) {
      if (n.nodeType === 3) {
        if (n.textContent) out.push({ t: n.textContent, s: st });
        return;
      }
      if (n.nodeType !== 1) return;
      if (n.tagName === "BR") { out.push({ br: true, s: st }); return; }
      if (n.tagName === "IMG") {
        const src = n.getAttribute("src") || "";
        if (src.startsWith("data:")) {
          images.push({ src, el: n });
          out.push({ img: images.length - 1, s: st, el: n });
        }
        return;
      }
      const next = inheritStyle(n, st);
      n.childNodes.forEach((c) => walk(c, next));
    }
    node.childNodes.forEach((c) => walk(c, style));
    return out;
  }

  function runXml(run, images, rels) {
    if (run.img != null) {
      const img = images[run.img];
      const id = "rId" + rels.push({ type: "image", target: "media/" + img.name });
      const cx = img.cx, cy = img.cy;
      return `<w:r><w:drawing>
        <wp:inline distT="0" distB="0" distL="0" distR="0">
          <wp:extent cx="${cx}" cy="${cy}"/>
          <wp:effectExtent l="0" t="0" r="0" b="0"/>
          <wp:docPr id="${run.img + 1}" name="Picture ${run.img + 1}"/>
          <wp:cNvGraphicFramePr><a:graphicFrameLocks xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" noChangeAspect="1"/></wp:cNvGraphicFramePr>
          <a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
            <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
              <pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
                <pic:nvPicPr><pic:cNvPr id="${run.img + 1}" name="Picture ${run.img + 1}"/><pic:cNvPicPr/></pic:nvPicPr>
                <pic:blipFill><a:blip r:embed="${id}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>
                <pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>
              </pic:pic>
            </a:graphicData>
          </a:graphic>
        </wp:inline>
      </w:drawing></w:r>`;
    }
    const s = run.s || {};
    let rPr = "";
    if (s.font) rPr += `<w:rFonts w:ascii="${escapeAttr(s.font)}" w:hAnsi="${escapeAttr(s.font)}"/>`;
    if (s.bold) rPr += "<w:b/>";
    if (s.italic) rPr += "<w:i/>";
    if (s.underline) rPr += '<w:u w:val="single"/>';
    if (s.strike) rPr += "<w:strike/>";
    if (s.color) rPr += `<w:color w:val="${s.color}"/>`;
    if (s.sz) rPr += `<w:sz w:val="${s.sz}"/><w:szCs w:val="${s.sz}"/>`;
    if (s.fill && s.fill !== "FFFFFF") rPr += `<w:shd w:val="clear" w:color="auto" w:fill="${s.fill}"/>`;
    if (s.sub) rPr += '<w:vertAlign w:val="subscript"/>';
    if (s.sup) rPr += '<w:vertAlign w:val="superscript"/>';
    const props = rPr ? `<w:rPr>${rPr}</w:rPr>` : "";
    if (run.br) return `<w:r>${props}<w:br/></w:r>`;
    const text = escapeXml(run.t || "");
    const inner = `<w:r>${props}<w:t xml:space="preserve">${text}</w:t></w:r>`;
    if (s.href) {
      const id = "rId" + rels.push({ type: "link", target: s.href });
      return `<w:hyperlink r:id="${id}">${inner}</w:hyperlink>`;
    }
    return inner;
  }

  function pPr(tag, align, numId) {
    let p = "";
    if (tag === "H1") p += '<w:pStyle w:val="Heading1"/>';
    else if (tag === "H2") p += '<w:pStyle w:val="Heading2"/>';
    else if (tag === "H3") p += '<w:pStyle w:val="Heading3"/>';
    else if (tag === "BLOCKQUOTE") p += '<w:pStyle w:val="Quote"/>';
    if (numId) p += `<w:numPr><w:ilvl w:val="0"/><w:numId w:val="${numId}"/></w:numPr>`;
    if (align === "center") p += '<w:jc w:val="center"/>';
    if (align === "right") p += '<w:jc w:val="right"/>';
    if (align === "justify") p += '<w:jc w:val="both"/>';
    return p ? `<w:pPr>${p}</w:pPr>` : "";
  }

  function alignOf(el) {
    const a = (el.style && el.style.textAlign) || "";
    if (a === "center" || a === "right" || a === "justify") return a;
    return "";
  }

  function paragraphXml(el, style, images, rels, numId) {
    const runs = runsFrom(el, style, images).map((r) => runXml(r, images, rels)).join("");
    return `<w:p>${pPr(el.tagName, alignOf(el), numId)}${runs || "<w:r><w:t></w:t></w:r>"}</w:p>`;
  }

  function tableXml(table, images, rels, nums) {
    const rows = [...table.rows];
    const body = rows.map((row) => {
      const cells = [...row.cells].map((cell) => {
        const ps = cell.innerText.trim()
          ? paragraphXml(cell, {}, images, rels)
          : "<w:p/>";
        return `<w:tc><w:tcPr><w:tcW w:w="2400" w:type="dxa"/></w:tcPr>${ps}</w:tc>`;
      }).join("");
      return `<w:tr>${cells}</w:tr>`;
    }).join("");
    return `<w:tbl><w:tblPr><w:tblW w:w="5000" w:type="pct"/><w:tblBorders>
      <w:top w:val="single" w:sz="4" w:space="0" w:color="8A8886"/>
      <w:left w:val="single" w:sz="4" w:space="0" w:color="8A8886"/>
      <w:bottom w:val="single" w:sz="4" w:space="0" w:color="8A8886"/>
      <w:right w:val="single" w:sz="4" w:space="0" w:color="8A8886"/>
      <w:insideH w:val="single" w:sz="4" w:space="0" w:color="8A8886"/>
      <w:insideV w:val="single" w:sz="4" w:space="0" w:color="8A8886"/>
    </w:tblBorders></w:tblPr>${body}</w:tbl>`;
  }

  function blocksFrom(root, images, rels, nums) {
    let xml = "";
    function list(ul, ordered) {
      const numId = nums.next++;
      nums.defs.push({ id: numId, ordered });
      [...ul.children].forEach((li) => {
        if (li.tagName === "LI") xml += paragraphXml(li, {}, images, rels, numId);
      });
    }
    function walk(node) {
      [...node.childNodes].forEach((child) => {
        if (child.nodeType === 3) {
          if (child.textContent.trim()) xml += `<w:p><w:r><w:t xml:space="preserve">${escapeXml(child.textContent)}</w:t></w:r></w:p>`;
          return;
        }
        if (child.nodeType !== 1) return;
        const tag = child.tagName;
        if (tag === "DIV" && child.classList.contains("page-break")) {
          xml += '<w:p><w:r><w:br w:type="page"/></w:r></w:p>';
          return;
        }
        if (tag === "TABLE") { xml += tableXml(child, images, rels, nums); return; }
        if (tag === "UL") { list(child, false); return; }
        if (tag === "OL") { list(child, true); return; }
        if (tag === "HR") { xml += '<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="auto"/></w:pBdr></w:pPr></w:p>'; return; }
        if (/^(P|H1|H2|H3|BLOCKQUOTE)$/.test(tag)) { xml += paragraphXml(child, {}, images, rels); return; }
        if (tag === "DIV") { walk(child); return; }
        xml += paragraphXml(child, {}, images, rels);
      });
    }
    walk(root);
    return xml || "<w:p/>";
  }

  async function prepareImages(images) {
    let i = 1;
    for (const img of images) {
      const m = img.src.match(/^data:(image\/[a-zA-Z0+.-]+);base64,(.+)$/);
      img.mime = m ? m[1] : "image/png";
      img.ext = img.mime.includes("jpeg") ? "jpeg" : img.mime.includes("gif") ? "gif" : "png";
      img.name = "image" + i + "." + img.ext;
      img.bytes = Uint8Array.from(atob(m ? m[2] : ""), (c) => c.charCodeAt(0));
      const w = img.el.naturalWidth || img.el.width || 400;
      const h = img.el.naturalHeight || img.el.height || 300;
      const max = 540;
      const scale = w > max ? max / w : 1;
      img.cx = Math.round(w * scale * 9525);
      img.cy = Math.round(h * scale * 9525);
      i++;
    }
  }

  function pageSetup() {
    const letter = state.size !== "a4";
    let w = letter ? 12240 : 11906;
    let h = letter ? 15840 : 16838;
    if (state.orient === "landscape") { const t = w; w = h; h = t; }
    const margin = state.margin === "m-narrow" ? 720 : state.margin === "m-wide" ? 1800 : 1440;
    return `<w:sectPr><w:pgSz w:w="${w}" w:h="${h}" w:orient="${state.orient}"/><w:pgMar w:top="${margin}" w:right="${margin}" w:bottom="${margin}" w:left="${margin}" w:header="720" w:footer="720" w:gutter="0"/></w:sectPr>`;
  }

  async function buildDocxBlob() {
    if (typeof JSZip === "undefined") throw new Error("Save library failed to load");
    const images = [];
    const rels = [{ type: "styles", target: "styles.xml" }, { type: "numbering", target: "numbering.xml" }];
    const nums = { next: 1, defs: [] };
    const body = blocksFrom(doc, images, rels, nums);
    await prepareImages(images);
    const zip = new JSZip();
    zip.file("[Content_Types].xml", contentTypes(images));
    zip.folder("_rels").file(".rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>`);
    const relXml = rels.map((r, i) => {
      const id = "rId" + (i + 1);
      if (r.type === "styles") return `<Relationship Id="${id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>`;
      if (r.type === "numbering") return `<Relationship Id="${id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" Target="numbering.xml"/>`;
      if (r.type === "image") return `<Relationship Id="${id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="${r.target}"/>`;
      return `<Relationship Id="${id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" Target="${escapeAttr(r.target)}" TargetMode="External"/>`;
    }).join("");
    zip.folder("word").folder("_rels").file("document.xml.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${relXml}</Relationships>`);
    zip.folder("word").file("document.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
  <w:body>${body}${pageSetup()}</w:body>
</w:document>`);
    zip.folder("word").file("styles.xml", stylesXml());
    zip.folder("word").file("numbering.xml", numberingXml(nums.defs));
    images.forEach((img) => zip.folder("word").folder("media").file(img.name, img.bytes));
    return zip.generateAsync({ type: "blob", mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" });
  }

  function contentTypes(images) {
    const extras = images.map((img) => `<Override PartName="/word/media/${img.name}" ContentType="${img.mime}"/>`).join("");
    const defaults = [
      ["rels", "application/vnd.openxmlformats-package.relationships+xml"],
      ["xml", "application/xml"],
      ["png", "image/png"],
      ["jpeg", "image/jpeg"],
      ["gif", "image/gif"]
    ].map(([e, t]) => `<Default Extension="${e}" ContentType="${t}"/>`).join("");
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  ${defaults}
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
  <Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/>
  ${extras}
</Types>`;
  }

  function stylesXml() {
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri"/><w:sz w:val="22"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:rPr><w:color w:val="2E75B6"/><w:sz w:val="32"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:rPr><w:color w:val="2E75B6"/><w:sz w:val="26"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Heading3"><w:name w:val="heading 3"/><w:basedOn w:val="Normal"/><w:rPr><w:b/><w:color w:val="1F4E79"/><w:sz w:val="24"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Quote"><w:name w:val="Quote"/><w:basedOn w:val="Normal"/><w:rPr><w:i/><w:color w:val="595959"/></w:rPr></w:style>
</w:styles>`;
  }

  function numberingXml(defs) {
    const abstracts = defs.map((d, i) => `<w:abstractNum w:abstractNumId="${i}"><w:multiLevelType w:val="hybridMultilevel"/>
      <w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="${d.ordered ? "decimal" : "bullet"}"/>
      <w:lvlText w:val="${d.ordered ? "%1." : "•"}"/><w:lvlJc w:val="left"/></w:lvl></w:abstractNum>`).join("");
    const nums = defs.map((d, i) => `<w:num w:numId="${d.id}"><w:abstractNumId w:val="${i}"/></w:num>`).join("");
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:numbering xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">${abstracts}${nums}</w:numbering>`;
  }

  /* ---------- backstage ---------- */
  function openBackstage(which) {
    document.getElementById("backstage").classList.add("open");
    document.querySelectorAll(".bs-nav button").forEach((b) => b.classList.toggle("on", b.dataset.bs === which));
    const main = document.getElementById("bs-main");
    const info = `
      <h2>${escapeHtml(nameInput.value)}</h2>
      <p class="lead">Edam-word document. Save writes a real .docx that Word, Google Docs, and LibreOffice can open.</p>
      <div class="info-grid">
        <div>Words</div><div>${wordCount()}</div>
        <div>Paper</div><div>${state.size === "a4" ? "A4" : "Letter"}, ${state.orient}</div>
        <div>Margins</div><div>${state.margin === "m-narrow" ? "Narrow" : state.margin === "m-wide" ? "Wide" : "Normal"}</div>
        <div>Status</div><div>${state.dirty ? "Unsaved changes" : "Saved"}</div>
      </div>`;
    const views = {
      info,
      new: `<h2>New</h2><p class="lead">Start a blank page. Unsaved work is discarded after you confirm.</p>
        <div class="cards"><button class="card" id="bs-new"><strong>Blank document</strong><span>Calibri 11, Letter, normal margins</span></button></div>`,
      open: `<h2>Open</h2><p class="lead">Word .docx is the native format. Plain text and HTML open too. Old .doc files need to be saved as .docx first.</p>
        <div class="cards"><button class="card" id="bs-open"><strong>Browse</strong><span>This computer</span></button></div>`,
      save: `<h2>Save</h2><p class="lead">Choose Word, PDF, Rich Text, HTML, Markdown, or plain text.</p>
        <div class="cards"><button class="card" id="bs-save"><strong>Save as...</strong><span>Pick a format</span></button></div>`,
      saveas: `<h2>Save As</h2><p class="lead">Same formats as Save.</p>
        <div class="cards"><button class="card" id="bs-saveas"><strong>Choose format</strong><span>.docx, .pdf, .rtf, .html, .md, .txt</span></button></div>`,
      print: `<h2>Print</h2><p class="lead">Uses the browser print dialog. Choose “Save as PDF” there for a PDF copy.</p>
        <div class="cards"><button class="card" id="bs-print"><strong>Print</strong><span>Or save as PDF</span></button></div>`,
      export: `<h2>Export</h2><p class="lead">Download a copy in another format.</p>
        <div class="cards"><button class="card" id="bs-xhtml"><strong>Choose format</strong><span>.docx, .pdf, .rtf, .html, .md, .txt</span></button></div>`
    };
    main.innerHTML = views[which] || info;
    const bind = (id, fn) => { const n = document.getElementById(id); if (n) n.onclick = fn; };
    bind("bs-new", newDoc);
    bind("bs-open", openFile);
    bind("bs-save", openSaveDialog);
    bind("bs-saveas", openSaveDialog);
    bind("bs-xhtml", openSaveDialog);
    bind("bs-print", () => window.print());
  }
  function closeBackstage() { document.getElementById("backstage").classList.remove("open"); }

  function bindFind() {
    const bar = document.getElementById("findbar");
    document.getElementById("find-close").onclick = () => bar.classList.remove("open");
    document.getElementById("find-next").onclick = () => {
      const q = document.getElementById("find-q").value;
      if (!q) return;
      if (!window.find(q, false, false, true)) toast("No more matches");
    };
    document.getElementById("replace-one").onclick = () => {
      const q = document.getElementById("find-q").value;
      const r = document.getElementById("replace-q").value;
      if (!q) return;
      if (window.find(q, false, false, true)) {
        document.execCommand("insertText", false, r);
        markDirty();
      }
    };
    document.getElementById("replace-all").onclick = () => {
      const q = document.getElementById("find-q").value;
      const r = document.getElementById("replace-q").value;
      if (!q) return;
      const html = doc.innerHTML.split(q).join(r);
      doc.innerHTML = html;
      markDirty();
      toast("Replaced matches");
    };
  }

  function keys(e) {
    const meta = e.ctrlKey || e.metaKey;
    if (meta && e.key.toLowerCase() === "s") { e.preventDefault(); save(false); }
    if (meta && e.key.toLowerCase() === "o") { e.preventDefault(); openFile(); }
    if (meta && e.key.toLowerCase() === "p") { e.preventDefault(); window.print(); }
    if (meta && e.key.toLowerCase() === "n") { e.preventDefault(); newDoc(); }
    if (meta && e.key.toLowerCase() === "f") {
      e.preventDefault();
      document.getElementById("findbar").classList.add("open");
      document.getElementById("find-q").focus();
    }
    if (e.key === "Escape") closeBackstage();
  }

  function init() {
    fillSelects();
    bindRibbon();
    bindFind();
    doc.innerHTML = welcome;
    wordCount();
    markClean();
    doc.addEventListener("input", () => { markDirty(); wordCount(); saveRange(); });
    doc.addEventListener("mouseup", saveRange);
    doc.addEventListener("keyup", saveRange);
    document.addEventListener("selectionchange", saveRange);
    nameInput.addEventListener("input", () => { markDirty(); document.title = nameInput.value + " — Edam-word"; });
    document.getElementById("qa-save").onclick = openSaveDialog;
    document.getElementById("qa-save").title = "Save as (Ctrl+S saves .docx)";
    document.getElementById("qa-undo").onclick = () => document.execCommand("undo");
    document.getElementById("qa-redo").onclick = () => document.execCommand("redo");
    document.getElementById("qa-print").onclick = () => window.print();
    document.getElementById("close-bs").onclick = closeBackstage;
    document.querySelectorAll(".bs-nav button[data-bs]").forEach((b) => {
      b.onclick = () => openBackstage(b.dataset.bs);
    });
    document.getElementById("file-input").addEventListener("change", (e) => {
      const f = e.target.files && e.target.files[0];
      if (f) { state.fileHandle = null; loadFile(f); closeBackstage(); }
      e.target.value = "";
    });
    document.getElementById("img-input").addEventListener("change", (e) => {
      const f = e.target.files && e.target.files[0];
      if (!f) return;
      const reader = new FileReader();
      reader.onload = () => {
        doc.focus();
        document.execCommand("insertHTML", false, '<p><img src="' + reader.result + '" alt=""></p>');
        markDirty();
      };
      reader.readAsDataURL(f);
      e.target.value = "";
    });
    document.getElementById("zoom").addEventListener("input", (e) => setZoom(Number(e.target.value)));
    document.getElementById("zoom-in").onclick = () => setZoom(state.zoom + 10);
    document.getElementById("zoom-out").onclick = () => setZoom(state.zoom - 10);
    document.addEventListener("keydown", keys);
    document.getElementById("workspace").addEventListener("dragover", (e) => e.preventDefault());
    document.getElementById("workspace").addEventListener("drop", (e) => {
      e.preventDefault();
      const f = e.dataTransfer.files && e.dataTransfer.files[0];
      if (f) { state.fileHandle = null; loadFile(f); }
    });
    window.addEventListener("beforeunload", (e) => {
      if (state.dirty) { e.preventDefault(); e.returnValue = ""; }
    });
    syncRuler();
    const compat = document.getElementById("compat");
    if (compat) compat.textContent = "ready";
  }

  init();
})();
