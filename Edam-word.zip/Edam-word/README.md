# Edam-word

A Word-style document editor that opens `.docx`, edits on a page, and saves a real Word file.

## Open it

1. Unzip this folder if you downloaded the archive.
2. Double-click `index.html`, or serve the folder and open it in Chrome or Edge.

Chrome and Edge can save back into the file you opened. Other browsers download a new `.docx`.

## What it covers

- File backstage: New, Open, Save, Save As, Print, Export
- Home ribbon: font, size, bold, italic, underline, strike, sub/sup, color, highlight, lists, alignment, line spacing, styles
- Insert: tables, pictures, links, page breaks, lines, text boxes
- Layout: margins, portrait/landscape, Letter/A4
- Review: word count, spelling toggle
- View: ruler, ribbon, read mode, zoom
- Drag a `.docx` onto the page
- Ctrl+S save, Ctrl+O open, Ctrl+F find, Ctrl+P print

## Honest limit

This is not Microsoft Word. Macros, mail merge, SmartArt, equations, comments, and tracked changes are not implemented. Complex section layouts may simplify on open. Everyday letters, reports, headings, lists, tables, and pictures are the target.
